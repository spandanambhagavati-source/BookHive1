console.log("Welcome to BookHive! 🛒"); 
const SITE_NAME = "BookHive"; 
const FOUNDED_YEAR = 2026; 
const PI = 3.14159;
let cartCount = 0; 
let totalAmount = 0; 
let currentUser = null;
console.log(SITE_NAME); 
console.log("Founded:", FOUNDED_YEAR); 
console.log("Cart count:", cartCount); 
cartCount = 0; 
totalAmount = 1497; 
console.log("New cart count:", cartCount); 
console.log("Total amount: ₹" + totalAmount); 
const bookTitle = "Wings of Fire"; 
const author = 'A.P.J. Abdul Kalam';        // single quotes work too 
const description = `Bestseller since 1999`;
const price = 299; 
const discount = 0.20;        // 20% 
const rating = 4.8;
const isInStock = true; 
const isOnSale = false;
const couponCode = null; 
let promoMessage;   
console.log(typeof bookTitle);  // "string" 
console.log(typeof price);       // "number" 
console.log(typeof isInStock);   // "boolean" 
console.log(typeof promoMessage); 
const message1 = "Hello, " + author + "! Your book '" + bookTitle + "' costs ₹" + 
price;
const message2 = `Hello, ${author}! Your book '${bookTitle}' costs ₹${price}`;
console.log(message1); 
console.log(message2);
const productCard = ` 
    <div class="book-card"> 
        <h3>${bookTitle}</h3> 
        <p>by ${author}</p> 
        <p>₹${price}</p> 
    </div> 
`; 
console.log(productCard);
const bookPrice = 299; 
const quantity = 3;
const subtotal = bookPrice * quantity;           // 897 
const tax = subtotal * 0.05;                     // 5% GST 
const total = subtotal + tax;                    // 941.85 
const discount = total * 0.10;                   // 10% off 
const finalPrice = total - discount;             // 847.665
console.log("Subtotal:", subtotal); 
console.log("Tax:", tax); 
console.log("Total:", total); 
console.log("After discount:", finalPrice);
console.log("Final:", finalPrice.toFixed(2));    
console.log(Math.round(4.7));    // 5 (rounds to nearest) 
console.log(Math.ceil(4.2));     // 5 (always rounds up) 
console.log(Math.floor(4.9));    // 4 (always rounds down) 
console.log(Math.max(10, 20));   // 20 
console.log(Math.min(10, 20));   // 10 
console.log(Math.random());  
const heroTitle = document.getElementById("hero-title"); 
const heroSubtitle = document.getElementById("hero-subtitle");
console.log("Current title:", heroTitle.textContent);
heroTitle.textContent = "Welcome to BookHive"; 
const currentHour = new Date().getHours(); 
let greeting; 
  
if (currentHour < 12) { 
    greeting = "Good Morning! 🛒"; 
} else if (currentHour < 17) { 
    greeting = "Good Afternoon! 🛒"; 
} else { 
    greeting = "Good Evening! 🛒"; 
} 
  
heroSubtitle.textContent = `${greeting} Find your next great read.`; 
const heroTitle = document.getElementById("hero-title"); 
const allBookCards = document.getElementsByClassName("book-card"); 
const firstCard = document.querySelector(".book-card"); 
const titleByQuery = document.querySelector("#hero-title"); 
const allCardsQuery = document.querySelectorAll(".book-card"); 
console.log("Number of book cards:", allCardsQuery.length); 
  
let cartCount = 0; 
  
function updateCartCount() { 
    const cartCountElement = document.getElementById("cart-count"); 
    if (cartCountElement) { 
        cartCountElement.textContent = cartCount; 
    } 
} 
cartCount = 3; 
updateCartCount(); 
const books = [ 
    { 
        id: 1, 
        title: "Wings of Fire", 
        author: "A.P.J. Abdul Kalam", 
        category: "biography", 
        price: 299, 
        originalPrice: 499, 
        rating: 4.8, 
        reviews: 2341, 
        image: "images/books/wings-of-fire.jpg", 
        description: "Autobiography of India's beloved former president.", 
        inStock: true 
    }, 
    { 
        id: 2, 
        title: "The Alchemist", 
        author: "Paulo Coelho", 
        category: "fiction", 
        price: 349, 
        originalPrice: 499, 
        rating: 4.7, 
        reviews: 5012, 
        image: "images/books/the-alchemist.jpg", 
        description: "A magical story about pursuing your dreams.", 
        inStock: true 
    }
{
     id: 3, 
        title: "Atomic Habits", 
        author: "James Clear", 
        category: "self-help", 
        price: 499, 
        originalPrice: 799, 
        rating: 4.9, 
        reviews: 8420, 
        image: "images/books/atomic-habits.jpg", 
        description: "Tiny changes, remarkable results.", 
        inStock: true 
    }, 
    { 
        id: 4, 
        title: "Sapiens", 
        author: "Yuval Noah Harari", 
        category: "history", 
        price: 599, 
        originalPrice: 899, 
        rating: 4.6, 
        reviews: 12450, 
        image: "images/books/sapiens.jpg", 
        description: "A brief history of humankind.", 
        inStock: true 
    }, 
    { 
        id: 5, 
        title: "Rich Dad Poor Dad", 
        author: "Robert Kiyosaki", 
        category: "business", 
        price: 350, 
        originalPrice: 499, 
        rating: 4.5, 
        reviews: 6800, 
        image: "images/books/rich-dad.jpg", 
        description: "What the rich teach their kids about money.", 
        inStock: true 
    }, 
    { 
        id: 6, 
        title: "Five Point Someone", 
        author: "Chetan Bhagat", 
        category: "fiction", 
        price: 199, 
        originalPrice: 299, 
        rating: 4.3, 
        reviews: 9200, 
        image: "images/books/five-point.jpg", 
        description: "What not to do at IIT.", 
       inStock: false 
    }, 
    { 
        id: 7, 
        title: "The Power of Subconscious Mind", 
        author: "Joseph Murphy", 
        category: "self-help", 
        price: 249, 
        originalPrice: 399, 
        rating: 4.6, 
        reviews: 4100, 
        image: "images/books/subconscious.jpg", 
        description: "Unlock the power within you.", 
        inStock: true
},

 { 
        id: 8, 
        title: "Think and Grow Rich", 
        author: "Napoleon Hill", 
        category: "business", 
        price: 299, 
        originalPrice: 499, 
        rating: 4.7, 
        reviews: 7300, 
        image: "images/books/think-grow.jpg", 
        description: "The classic guide to success.", 
        inStock: true 
    } 
]; 
  
console.log(`Loaded ${books.length} books`);
function createBookCard(book) { 
    return ` 
        <article class="book-card" data-id="${book.id}"> 
            <img src="${book.image}" alt="${book.title}" loading="lazy"> 
            <h3>${book.title}</h3> 
            <p class="author">${book.author}</p> 
            <p class="rating">⭐ ${book.rating} (${book.reviews} reviews)</p> 
            <p class="price"> 
                ₹${book.price} 
                <small><s>₹${book.originalPrice}</s></small> 
            </p> 
            <button 
                class="add-to-cart" 
                data-id="${book.id}" 
                ${!book.inStock ? "disabled" : ""} 
            > 
                ${book.inStock ? "Add to Cart" : "Out of Stock"} 
            </button> 
        </article> 
    `; 
}
function renderBooks(bookList) { 
    if (!booksContainer) return; 
    const allHTML = bookList.map(book => createBookCard(book)).join(""); 
     booksContainer.innerHTML = allHTML;
}
renderBooks(books); 
const titles = books.map(book => book.title); 
console.log(titles); 
const titlesWithPrices = books.map(book => 
    `${book.title} - ₹${book.price}` 
); 
console.log(titlesWithPrices);
const booksWithDiscount = books.map(book => ({ 
    ...book, 
    discount: Math.round(((book.originalPrice - book.price) / book.originalPrice) 
* 100) 
})); 
const availableBooks = books.filter(book => book.inStock); 
console.log(`${availableBooks.length} books in stock`);
const fictionBooks = books.filter(book => book.category === "fiction"); 
const cheapBooks = books.filter(book => book.price < 300); 
const topRated = books.filter(book => book.rating >= 4.7); 
const searchTerm = "atom"; 
const matching = books.filter(book => 
    book.title.toLowerCase().includes(searchTerm.toLowerCase()) 
); 
console.log("Search results:", matching); 
const totalPrice = books.reduce((sum, book) => sum + book.price, 0); 
console.log("Total catalog value: ₹" + totalPrice);
const totalRating = books.reduce((sum, book) => sum + book.rating, 0); 
const averageRating = totalRating / books.length; 
console.log("Average rating:", averageRating.toFixed(1));
const byCategory = books.reduce((groups, book) => { 
    if (!groups[book.category]) { 
        groups[book.category] = []; 
    } 
    groups[book.category].push(book); 
    return groups; 
}, {}); 
console.log(byCategory);
const sortedByPriceLow = [...books].sort((a, b) => a.price - b.price);
const sortedByPriceHigh = [...books].sort((a, b) => b.price - a.price); 
const sortedByRating = [...books].sort((a, b) => b.rating - a.rating); 
const sortedByRating = [...books].sort((a, b) => b.rating - a.rating); 
const wingsOfFire = books.find(book => book.id === 1); 
console.log(wingsOfFire);
const index = books.findIndex(book => book.id === 5); 
console.log("Found at index:", index);
const hasAtomicHabits = books.some(book => book.title === "Atomic Habits"); 
console.log(hasAtomicHabits);
const allWellRated = books.every(book => book.rating > 4); 
console.log(allWellRated);
let cart = []; 
const savedCart = localStorage.getItem("bookhive-cart"); 
if (savedCart) { 
    cart = JSON.parse(savedCart); 
}
function addToCart(bookId) { 
 const book = books.find(b => b.id === bookId); 
  
    if (!book) { 
        alert("Book not found!"); 
        return; 
    } 
  
    if (!book.inStock) { 
        alert("Sorry, this book is out of stock!"); 
        return; 
    }
     const existingItem = cart.find(item => item.id === bookId); 
  
    if (existingItem) { 
        existingItem.quantity += 1;
         } else { 
        // Add new item 
        cart.push({ 
            id: book.id, 
            title: book.title, 
            author: book.author, 
            price: book.price, 
            image: book.image, 
            quantity: 1 
        }); 
    }
     saveCart(); 
      updateCartCount(); 
        showNotification(`Added "${book.title}" to cart! 🛒`); 
} 
function saveCart() { 
    localStorage.setItem("bookhive-cart", JSON.stringify(cart)); 
} 
 function updateCartCount() { 
    const cartCountElement = document.getElementById("cart-count"); 
    if (cartCountElement) { 
        const totalQuantity = cart.reduce((sum, item) => sum + item.quantity, 0); 
        cartCountElement.textContent = totalQuantity; 
    } 
} 
  function showNotification(message) { 
    // Create notification element 
    const notification = document.createElement("div"); 
    notification.className = "notification"; 
    notification.textContent = message; 
document.body.appendChild(notification);
setTimeout(() => { 
        notification.remove(); 
    }, 3000); 
}
updateCartCount(); 
function attachAddToCartListeners() { 
    const buttons = document.querySelectorAll(".add-to-cart"); 
  
    buttons.forEach(button => { 
        button.addEventListener("click", function() { 
            // Get the book ID from the data-id attribute 
            const bookId = parseInt(this.getAttribute("data-id")); 
            addToCart(bookId); 
        }); 
    }); 
} 
renderBooks(books); 
attachAddToCartListeners(); 
let cart = [];

function addToCart(title, price) {
  cart.push({ title, price });
  document.getElementById("cart-count").innerText = cart.length;
  console.log("Cart:", cart);
}

 
  
  
